window.onload = function() {
  cubeInit();
  PlayerW.init();
  point();
}