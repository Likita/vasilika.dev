a = 5;
typeof a;
console.log('a=' + a);

b = 'Hello';
document.write(typeof b);

a = 4;
b = 7;
console.log(a + b == 10);

// alert('Закрой меня!');

// age = prompt('Сколько тебе лет?');
// console.log(age);

confirm('Уже есть 18?');