window.addEventListener('load', onLoad);

function onLoad() {
  let element = document.querySelector('.content');
  let parallax = new Parallax(element);
}
